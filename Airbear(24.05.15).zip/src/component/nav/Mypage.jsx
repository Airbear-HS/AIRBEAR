import React from 'react';
import './Mypage.css';

function Mypage() {
  return <div>Hi</div>;
}

export default Mypage;
