const Test = () => {
  return <h1>HI</h1>;
};

export default Test;
