import React from 'react';
import './Health.css';

function Health() {
  return <div>Hi</div>;
}

export default Health;
